/*
 *  l.c
 *  
 *
 *  Created by 会田 誠 on 11/04/07.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */

#include "l.h"

